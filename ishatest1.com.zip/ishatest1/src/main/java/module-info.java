module com.example.ishatest1 {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    opens com.example.ishatest1 to javafx.fxml;
    exports com.example.ishatest1;
}